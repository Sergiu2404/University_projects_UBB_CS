import static org.junit.jupiter.api.Assertions.*;
import org.example.PaymentProcessor;
import org.junit.jupiter.api.Test;

public class PaymentProcessorTest {

    private final PaymentProcessor processor = new PaymentProcessor();

    @Test
    void testProcessPayment_NegativeAmountThrows() {
        assertThrows(IllegalArgumentException.class, () -> {
            processor.processPayment(0.0, false, PaymentProcessor.PaymentMethod.CASH);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            processor.processPayment(-10.0, true, PaymentProcessor.PaymentMethod.CREDIT_CARD);
        });
    }

    @Test
    void testProcessPayment_FirstOrderCash() {
        double amount = 100.0;
        boolean isFirstOrder = true;
        PaymentProcessor.PaymentMethod method = PaymentProcessor.PaymentMethod.CASH;
        double result = processor.processPayment(amount, isFirstOrder, method);
        assertEquals(90.00, result);
    }

    @Test
    void testProcessPayment_FirstOrderCreditCard() {
        double amount = 100.0;
        boolean isFirstOrder = true;
        PaymentProcessor.PaymentMethod method = PaymentProcessor.PaymentMethod.CREDIT_CARD;
        double result = processor.processPayment(amount, isFirstOrder, method);
        assertEquals(85.00, result);
    }

    @Test
    void testProcessPayment_FirstOrderPayPal() {
        double amount = 200.0;
        boolean isFirstOrder = true;
        PaymentProcessor.PaymentMethod method = PaymentProcessor.PaymentMethod.PAYPAL;
        double result = processor.processPayment(amount, isFirstOrder, method);
        assertEquals(176.00, result);
    }

    @Test
    void testProcessPayment_NonFirstOrderCash() {
        double amount = 50.0;
        boolean isFirstOrder = false;
        PaymentProcessor.PaymentMethod method = PaymentProcessor.PaymentMethod.CASH;
        double result = processor.processPayment(amount, isFirstOrder, method);
        assertEquals(50.00, result);
    }

    @Test
    void testProcessPayment_NonFirstOrderCreditCard() {
        double amount = 100.0;
        boolean isFirstOrder = false;
        PaymentProcessor.PaymentMethod method = PaymentProcessor.PaymentMethod.CREDIT_CARD;
        double result = processor.processPayment(amount, isFirstOrder, method);
        assertEquals(95.00, result);
    }

    @Test
    void testProcessPayment_NonFirstOrderPayPal() {
        double amount = 200.0;
        boolean isFirstOrder = false;
        PaymentProcessor.PaymentMethod method = PaymentProcessor.PaymentMethod.PAYPAL;
        double result = processor.processPayment(amount, isFirstOrder, method);
        assertEquals(196.00, result);
    }

    @Test
    void testCalculateDeliveryFee_BelowThreshold() {
        double fee = processor.calculateDeliveryFee(49.99);
        assertEquals(5.0, fee);
    }

    @Test
    void testCalculateDeliveryFee_AtThreshold() {
        double fee = processor.calculateDeliveryFee(50.0);
        assertEquals(0.0, fee);
    }

    @Test
    void testCalculateDeliveryFee_AboveThreshold() {
        double fee = processor.calculateDeliveryFee(100.0);
        assertEquals(0.0, fee);
    }

    @Test
    void testProcessPaymentAndCalculateDeliveryFee_Integration() {
        double productAmount = 80.0;
        boolean isFirstOrder = false;
        PaymentProcessor.PaymentMethod method = PaymentProcessor.PaymentMethod.CREDIT_CARD;
        double payment = processor.processPayment(productAmount, isFirstOrder, method);
        double deliveryFee = processor.calculateDeliveryFee(productAmount);
        assertEquals(76.00, payment + deliveryFee);
    }
}